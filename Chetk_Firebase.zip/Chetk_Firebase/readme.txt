
** 500 :- Internal Server Error **
    - when system send and error

** 400 :- Internal Server Error **
    - server was unable to process a request due to a client error

** 401 :- Unauthorized Access Error **
    - suer unable to perform query
    - users data is missmatch or invalid

** 404 :- data not found ***
    - when user send data but its not fond on database

** 200 :- Success **
    - data send successfully
    - perform query successully


---------------------------------------------------------------------------
send status code to user

error_message - Error Messages only
success_message - success Messages only 
data - send data to user only when response code is 200

---------------------------------------------------------------------------






