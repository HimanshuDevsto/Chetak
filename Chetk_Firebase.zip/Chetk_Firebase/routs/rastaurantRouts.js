const express = require('express');
const { createRasturant } = require('../controllers/restaurantController');
const router = express.Router();


// POST /rastaurant - Create a new rastaurant
router.route("/").post( createRasturant );



module.exports = router;