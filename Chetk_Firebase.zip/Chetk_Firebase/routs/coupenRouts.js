const express = require('express');
const { createCoupen, editCoupen, deleteCoupen, getAllCoupons } = require('../controllers/coupnController');
const router = express.Router();


// POST /coupen - Create a new coupen
router.route("/").post( createCoupen );
router.route("/update").post( editCoupen );
router.route("/:id").delete( deleteCoupen );



router.route("/").get( getAllCoupons );

module.exports = router;