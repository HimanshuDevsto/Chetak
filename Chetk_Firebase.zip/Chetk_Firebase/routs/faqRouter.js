const express = require('express');
const { createFaq, editFaq, deleteFaq, getAllFaq } = require('../controllers/faqController');

const router = express.Router();


router.route("/").post( createFaq );
router.route("/").patch( editFaq );
router.route("/:id").delete( deleteFaq );


router.route("/").get( getAllFaq );


module.exports = router;