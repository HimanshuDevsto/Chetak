const db = require('../config/firebase');
const asyncHandler = require('express-async-handler');
const RASTAURANT_COLLECTION = db.collection("rastaurants");

// Create a new rasturant
const createRasturant = asyncHandler(async (req, res) => {
    try {
        const { name, email, phone } = req.body;

        //validations
        if ( !name || !email || !phone ){
            return res.status(401).json({ error_message: "All fields must be required ! \n name, email, phone"});
        }else{
            const rasturantExistsPhone = await RASTAURANT_COLLECTION.where('phone', '==', phone).limit(1).get();
            const rasturantExistsEmail = await RASTAURANT_COLLECTION.where('email', '==', email).limit(1).get();

            if (!email.match("^[a-z0-9+_.-]+@(.)+[a-z]$")) {
                return res.status(401).json({ error_message: "Invalid email format !" });
            }else if (phone.length !== 10) {
                return res.status(401).json({ error_message: "Invalid contact number format! It should be 10 digits." });
            }else if (!rasturantExistsPhone.empty)  {
                return res.status(401).json({ error_message: `Rastaurant is already exists with phone - '${phone}'`});
            }else if (!rasturantExistsEmail.empty)  {
                return res.status(401).json({ error_message: `Rastaurant is already exists with email - '${email}'`});
            }
        }

        // Create a new Rastaurant document in the Firestore collection
        const newRastaurant = { name, email, phone };
        const docRef = await RASTAURANT_COLLECTION.add(newRastaurant);

        // Set the document ID in the Rastaurant data
        const rastaurantData = { id: docRef.id, ...newRastaurant };
        await docRef.set(rastaurantData);

        res.status(200).json({ success_message: "Rastaurant created successfully!", data: rastaurantData });

    } catch (err) {
        console.log("SAVE NEW RASTAURANT ERROR :- ", err);
        res.status(500).json({ error_message: "Internal server error!" });
    }
});


module.exports = { createRasturant };
