
const db = require('../config/firebase');
const asyncHandler = require('express-async-handler');
const COUPEN_COLLECTION = db.collection("coupens");


// Create New Coupen 
const createCoupen = asyncHandler(async (req, res) => {
    try {
        const { title, qty, category, value, min_purchase } = req.body;

        //validations
        if (!title || !qty || !category || !value || !min_purchase){
            res.status(401).json({ error_message: "All fields must be required ! \n title, qty, category, value, min_purchase"});
        }

        const querySnapshot = await COUPEN_COLLECTION.where('title', '==', title).limit(1).get();

        // Check if any coupons were found
        if (!querySnapshot.empty) {
            return res.status(401).json({ message: `coupen is already exists with same title ${title}` });
        }


        // Create a new coupen document in the Firestore collection
        const newcoupen = { 
            title, 
            qty, 
            category, 
            value, 
            min_purchase 
        };

        const docRef = await COUPEN_COLLECTION.add(newcoupen);

        // Set the document ID in the coupen data
        const coupenData = { id: docRef.id, ...newcoupen };
        await docRef.set(coupenData);

        res.status(200).json({ success_message: "Coupen created successfully!", data: coupenData });

    } catch (err) {
        console.log("SAVE NEW COUPEN ERROR :- ", err);
        res.status(500).json({ error_message: "Internal server error!" });
    }
});

// Edit Coupen 
const editCoupen = asyncHandler(async (req, res) => {
    try {
        const { id, title, qty, category, value, min_purchase } = req.body;

        // Validations
        if (!id || !title || !qty || !category || !value || !min_purchase) {
            return res.status(400).json({ error_message: "All fields must be required! \n id, title, qty, category, value, min_purchase" });
        }

        // Validate coupen availability
        const coupenDoc = COUPEN_COLLECTION.doc(id);
        const coupen = await coupenDoc.get();

        if (!coupen.exists) {
            return res.status(404).json({ error_message: "Invalid coupen id!" });
        }


        const querySnapshot = await COUPEN_COLLECTION.where('title', '==', title).where('id', '!=', id).limit(1).get();
        
        // Check if any coupons were found
        if (!querySnapshot.empty) {
            return res.status(401).json({ message: `coupen is already exists with same title ${title}` });
        }


        const updatedCoupen = { 
            title, 
            qty, 
            category, 
            value, 
            min_purchase 
        };

        // Update coupen data
        await coupenDoc.update(updatedCoupen);
        return res.status(200).json({ success_message: "Coupen updated successfully!", data: updatedCoupen });

    } catch (err) {
        console.log("EDIT COUPEN ERROR :- ", err);
        return res.status(500).json({ error_message: "Internal server error!" });
    }
});

// Delete Coupen 
const deleteCoupen = asyncHandler(async (req, res) => {
    try {
        const { id } = req.params;

        // Validations
        if (!id) {
            return res.status(400).json({ error_message: "id must be required!" });
        }

        const coupenDoc = COUPEN_COLLECTION.doc(id);

        // Validate coupen availability
        const coupen = await coupenDoc.get();

        if (!coupen.exists) {
            return res.status(404).json({ error_message: "Invalid coupen id!" });
        }

        // Delete coupen data
        await coupenDoc.delete();
        return res.status(200).json({ success_message: "Coupen deleted successfully!" });


    }catch (err) {
        console.log("DELETE COUPEN ERROR :- ", err);
        return res.status(500).json({ error_message: "Internal server error!" });
    }
});

// Get All Coupens - For Admin Only 
const getAllCoupons = asyncHandler(async (req, res) => {
    try {
        const coupenCollection = COUPEN_COLLECTION;
        const snapshot = await coupenCollection.get();

        // Check if there are any coupons
        if (snapshot.empty) {
            return res.status(404).json({ message: "No coupons found." });
        }

        // Create an array to hold the coupon data
        const coupons = [];
        snapshot.forEach(doc => {
            coupons.push({  ...doc.data() }); // Include the document ID in the response
        });

        return res.status(200).json({ success: true, data: coupons });

    } catch (err) {
        console.error("GET ALL COUPONS ERROR:", err);
        return res.status(500).json({ error_message: "Internal server error!" });
    }
});

module.exports = { createCoupen, editCoupen, deleteCoupen, getAllCoupons };
