const db = require('../config/firebase');
const asyncHandler = require('express-async-handler');
const USER_COLLECTION = db.collection("users");


// Create a new user
const createUser = asyncHandler(async (req, res) => {
    try {
        const { name, email, phone } = req.body;

        if ( !name || !email || !phone ){
            return res.status(401).json({ error_message: "All fields must be required ! \n name, email, phone"});
        }else{
            const rasturantExistsPhone = await USER_COLLECTION.where('phone', '==', phone).limit(1).get();
            const rasturantExistsEmail = await USER_COLLECTION.where('email', '==', email).limit(1).get();
        
            if (!email.match("^[a-z0-9+_.-]+@(.)+[a-z]$")) {
                return res.status(401).json({ error_message: "Invalid email format !" });
            }else if (phone.length !== 10) {
                return res.status(401).json({ error_message: "Invalid contact number format! It should be 10 digits." });
            }else if (!rasturantExistsPhone.empty)  {
                return res.status(401).json({ error_message: `User is already exists with phone - '${phone}'`});
            }else if (!rasturantExistsEmail.empty)  {
                return res.status(401).json({ error_message: `User is already exists with email - '${email}'`});
            }
        }

        // Create a new user document in the Firestore collection
        const newUser = { name, email, phone };
        const docRef = await USER_COLLECTION.add(newUser);

        // Set the document ID in the user data
        const userData = { id: docRef.id, ...newUser };
        await docRef.set(userData);

        return res.status(200).json({ success_message: "User created successfully!", data: userData });

    } catch (err) {
        console.log("SAVE NEW USER ERROR :- ", err);
        return res.status(500).json({ error_message: "Internal server error!" });
    }
});

//Get All Users - Admin only
const getAllUsers = asyncHandler(async (req, res) => {
    try {
        const snapshot = await USER_COLLECTION.get();

        // Collect all documents data
        let data = [];
        snapshot.forEach(doc => {
            data.push({ ...doc.data() });
        });

        res.status(200).json(data);

    } catch (err) {
        console.log("SAVE NEW USER ERROR :- ", err);
        res.status(500).json({ error_message: "Internal server error!" });
    }
});



module.exports = { createUser, getAllUsers };
