const db = require('../config/firebase');
const asyncHandler = require('express-async-handler');
const FAQ_COLLECTION = db.collection("FAQs");


// Create a new FAQ
const createFaq = asyncHandler(async (req, res) => {
    try {
        // questioner must in ( customer, restaurants )
        const { question, ans, questioner } = req.body;

        //validations
        if ( !question || !ans || !questioner ){
            res.status(401).json({ error_message: "All fields must be required ! \n question, ans, questioner"});
        }else if (questioner != "customer" &&  questioner != "restaurants" ) {
            res.status(401).json({ error_message: "questioner should be ( customer or restaurants )"});
        }

        // Create a new FAQ document in the Firestore collection
        const newFaq = { question, ans, questioner };
        const docRef = await FAQ_COLLECTION.add(newFaq);

        // Set the document ID in the FAQ data
        const faqData = { id: docRef.id, ...newFaq };
        await docRef.set(faqData);

        res.status(200).json({ success_message: "FAQ created successfully!", data: faqData });

    } catch (err) {
        console.log("SAVE NEW FAQ ERROR :- ", err);
        res.status(500).json({ error_message: "Internal server error!" });
    }
});

// Edit a new FAQ
const editFaq = asyncHandler(async (req, res) => {
    try {
        // questioner must in ( customer, restaurants )
        const { id, question, ans, questioner } = req.body;

        //validations
        if ( !id || !question || !ans || !questioner ){
            res.status(401).json({ error_message: "All fields must be required ! \n id, question, ans, questioner"});
        }else if (questioner != "customer" &&  questioner != "restaurants" ) {
            res.status(401).json({ error_message: "questioner should be ( customer or restaurants )"});
        }

        // Validate FAQ availability
        const faqDoc = FAQ_COLLECTION.doc(id);
        const faq = await faqDoc.get();

        if (!faq.exists) {
            return res.status(404).json({ error_message: "Invalid faq id!" });
        }

        // Update FAQ document in the Firestore collection
        const updateFaq = { question, ans, questioner };
        await faqDoc.update(updateFaq);
 
        res.status(200).json({ success_message: "FAQ updated successfully!", data: updateFaq });

    } catch (err) {
        console.log("SAVE NEW FAQ ERROR :- ", err);
        res.status(500).json({ error_message: "Internal server error!" });
    }
});

// Delete FAQ
const deleteFaq = asyncHandler(async (req, res) => {
    try {
        
        const { id } = req.params;
    
        //validations
        if ( !id ){
            res.status(401).json({ error_message: " FAQ Id must be required ! "});
        }
    
        // Validate FAQ availability
        const faqDoc = FAQ_COLLECTION.doc(id);
        const faq = await faqDoc.get();
    
        if (!faq.exists) {
            return res.status(404).json({ error_message: "Invalid faq id!" });
        }
    
        // Update FAQ document in the Firestore collection
        await faqDoc.delete();
    
        res.status(200).json({ success_message: "FAQ deleted successfully!" });
    
    } catch (err) {
        console.log("SAVE NEW FAQ ERROR :- ", err);
        res.status(500).json({ error_message: "Internal server error!" });
    }
});

// Get All FAQs - For Admin Only 
const getAllFaq = asyncHandler(async (req, res) => {
    try {
        const faqCollection = FAQ_COLLECTION;
        const snapshot = await faqCollection.get();

        // Check if there are any faq
        if (snapshot.empty) {
            return res.status(404).json({ message: "No FAQs found." });
        }

        // Create an array to hold the faq data
        const faqs = [];
        snapshot.forEach(doc => {
            faqs.push({  ...doc.data() }); // Include the document ID in the response
        });

        return res.status(200).json({ success: true, data: faqs });

    } catch (err) {
        console.error("GET ALL FAQS ERROR:", err);
        return res.status(500).json({ error_message: "Internal server error!" });
    }
});

module.exports = { createFaq, editFaq, deleteFaq, getAllFaq };

