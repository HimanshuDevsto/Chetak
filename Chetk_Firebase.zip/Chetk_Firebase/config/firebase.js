require('dotenv').config();
const admin = require('firebase-admin');
const serviceAccount = require(process.env.FIREBASE_ADMIN_PATH);

// Initialize the Firebase Admin SDK
admin.initializeApp({
    credential: admin.credential.cert(serviceAccount)
});

// Export the Firestore instance
const db = admin.firestore();

// undifine property handeld
db.settings({
    ignoreUndefinedProperties: true,
});

module.exports = db;