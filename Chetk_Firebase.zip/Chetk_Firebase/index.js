const express = require("express");
const cors = require("cors");
require('dotenv').config()
const functions = require('firebase-functions');
const app = express();


// App configrations
require("./config/firebase");
app.use(cors());
app.use(express.json());


// App Routs
app.use('/users', require('./routs/userRouts'));
app.use('/rastaurant', require('./routs/rastaurantRouts'));
app.use('/coupen', require('./routs/coupenRouts'));
app.use('/faq', require('./routs/faqRouter'));



// App connections
const port = 3000;
app.listen(port, function () {
    console.log(`Express App running at http://127.0.0.1:${port}/`);
});

exports.api = functions.https.onRequest(app);